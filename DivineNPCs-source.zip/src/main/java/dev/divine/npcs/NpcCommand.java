package dev.divine.npcs;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public final class NpcCommand implements TabExecutor {
    private static final Pattern ID = Pattern.compile("[a-z0-9_-]{1,32}");
    private static final List<String> SUBS = List.of("help", "create", "remove", "list", "info", "tp",
            "movehere", "skin", "skinraw", "skinreset", "look", "lookrange", "holo", "cmd", "cooldown",
            "templates", "reload");
    private static final List<String> NEEDS_ID = List.of("remove", "delete", "info", "tp", "movehere", "skin",
            "skinraw", "skinreset", "look", "lookrange", "holo", "cmd", "cooldown");

    private final DivineNPCs plugin;
    private final NpcManager mgr;

    public NpcCommand(DivineNPCs plugin, NpcManager mgr) {
        this.plugin = plugin;
        this.mgr = mgr;
    }

    private void msg(CommandSender s, String mini) {
        plugin.send(s, mini);
    }

    private NpcData need(CommandSender s, String[] a, int idx, String usage) {
        if (a.length <= idx) {
            msg(s, "<gray>Usage: <white>" + usage);
            return null;
        }
        NpcData d = mgr.get(a[idx]);
        if (d == null) msg(s, "<red>No NPC with the id <white>" + a[idx] + "<red> exists.");
        return d;
    }

    private static String join(String[] a, int from) {
        return String.join(" ", Arrays.copyOfRange(a, from, a.length));
    }

    private static Integer parseInt(String s) {
        try { return Integer.parseInt(s); } catch (NumberFormatException e) { return null; }
    }

    private static Double parseDouble(String s) {
        try { return Double.parseDouble(s); } catch (NumberFormatException e) { return null; }
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("divinenpcs.admin")) {
            msg(s, "<red>You don't have permission to do that.");
            return true;
        }
        if (a.length == 0 || a[0].equalsIgnoreCase("help")) {
            help(s, label);
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> create(s, a);
            case "remove", "delete" -> remove(s, a);
            case "list" -> list(s);
            case "info" -> info(s, a);
            case "tp" -> tp(s, a);
            case "movehere" -> moveHere(s, a);
            case "skin" -> skin(s, a);
            case "skinraw" -> skinRaw(s, a);
            case "skinreset" -> skinReset(s, a);
            case "look" -> look(s, a);
            case "lookrange" -> lookRange(s, a);
            case "holo" -> holo(s, a);
            case "cmd" -> cmd(s, a);
            case "cooldown" -> cooldown(s, a);
            case "templates" -> templates(s);
            case "reload" -> reload(s);
            default -> msg(s, "<red>Unknown subcommand. Try <white>/" + label + " help");
        }
        return true;
    }

    private void help(CommandSender s, String l) {
        msg(s, "<gradient:#8A2BE2:#00BFFF><bold>DivineNPCs</bold></gradient> <gray>commands:");
        String[] lines = {
                "create <id> [template]", "remove <id>", "list", "info <id>", "tp <id>", "movehere <id>",
                "skin <id> <playername>", "skinraw <id> <value> <signature>", "skinreset <id>",
                "look <id> <on|off>", "lookrange <id> <blocks>",
                "holo <id> add <text>", "holo <id> set <line> <text>", "holo <id> remove <line>",
                "holo <id> clear", "holo <id> height <blocks>",
                "cmd <id> add <console|player|message> <text>", "cmd <id> remove <number>",
                "cmd <id> list", "cmd <id> clear", "cooldown <id> <seconds>", "templates", "reload"
        };
        for (String line : lines) s.sendMessage(Text.parse("<dark_gray>• <white>/" + l + " " + line));
    }

    private void create(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) {
            msg(s, "<red>Only players can create NPCs.");
            return;
        }
        if (a.length < 2) {
            msg(s, "<gray>Usage: <white>/dnpc create <id> [template]");
            return;
        }
        String id = a[1].toLowerCase(Locale.ROOT);
        if (!ID.matcher(id).matches()) {
            msg(s, "<red>The id may only contain a-z, 0-9, _ and - (max. 32 characters).");
            return;
        }
        if (mgr.get(id) != null) {
            msg(s, "<red>An NPC with that id already exists.");
            return;
        }
        var cfg = plugin.getConfig();
        ConfigurationSection sec;
        if (a.length >= 3) {
            sec = cfg.getConfigurationSection("templates." + a[2].toLowerCase(Locale.ROOT));
            if (sec == null) {
                msg(s, "<red>Unknown template. Available: <white>" + String.join(", ", templateNames()));
                return;
            }
        } else {
            sec = cfg.getConfigurationSection("defaults");
        }

        NpcData d = new NpcData(id);
        Location l = p.getLocation();
        d.world = l.getWorld().getName();
        d.x = l.getX();
        d.y = l.getY();
        d.z = l.getZ();
        d.yaw = l.getYaw();
        d.pitch = l.getPitch();
        d.lookRange = cfg.getDouble("look.default-range", 8.0);
        d.holoHeight = cfg.getDouble("hologram.default-height", 2.15);
        d.cooldown = cfg.getInt("interact.default-cooldown-seconds", 1);
        if (sec != null) {
            d.hologram.addAll(sec.getStringList("hologram"));
            d.commands.addAll(sec.getStringList("commands"));
            String skin = sec.getString("skin", "");
            if (!skin.isBlank()) d.skinName = skin;
        }
        mgr.add(d);
        msg(s, "<green>Created NPC <white>" + id + "<green>. Use <white>/dnpc skin " + id + " <name><green> to set a skin.");
    }

    private void remove(CommandSender s, String[] a) {
        NpcData d = need(s, a, 1, "/dnpc remove <id>");
        if (d == null) return;
        mgr.remove(d);
        msg(s, "<green>Removed NPC <white>" + d.id + "<green>.");
    }

    private void list(CommandSender s) {
        if (mgr.all().isEmpty()) {
            msg(s, "<gray>There are no NPCs yet. Create one with <white>/dnpc create <id> [template]");
            return;
        }
        msg(s, "<gray>NPCs (" + mgr.all().size() + "):");
        for (NpcData d : mgr.all()) {
            s.sendMessage(Text.parse("<dark_gray>• <white>" + d.id + " <gray>(" + d.world + " "
                    + Math.round(d.x) + " " + Math.round(d.y) + " " + Math.round(d.z) + ")"));
        }
    }

    private void info(CommandSender s, String[] a) {
        NpcData d = need(s, a, 1, "/dnpc info <id>");
        if (d == null) return;
        String skin = d.skinValue != null ? "custom texture" : (d.skinName != null ? d.skinName : "default");
        msg(s, "<gray>Info for <white>" + d.id);
        s.sendMessage(Text.parse("<dark_gray>• <gray>Location: <white>" + d.world + " " + Math.round(d.x) + " "
                + Math.round(d.y) + " " + Math.round(d.z)));
        s.sendMessage(Text.parse("<dark_gray>• <gray>Skin: <white>" + skin));
        s.sendMessage(Text.parse("<dark_gray>• <gray>Look at players: <white>" + (d.look ? "on" : "off")
                + " <gray>(range " + d.lookRange + ")"));
        s.sendMessage(Text.parse("<dark_gray>• <gray>Cooldown: <white>" + d.cooldown + "s"));
        s.sendMessage(Text.parse("<dark_gray>• <gray>Hologram lines: <white>" + d.hologram.size()
                + " <gray>(height " + d.holoHeight + ")"));
        int i = 1;
        for (String line : d.hologram) s.sendMessage(Text.parse("   <dark_gray>" + (i++) + ". <reset>" + line.replace("<", "\\<")));
        s.sendMessage(Text.parse("<dark_gray>• <gray>Click commands: <white>" + d.commands.size()));
        i = 1;
        for (String line : d.commands) s.sendMessage(Text.parse("   <dark_gray>" + (i++) + ". <white>" + line.replace("<", "\\<")));
    }

    private void tp(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) {
            msg(s, "<red>Only players can do that.");
            return;
        }
        NpcData d = need(s, a, 1, "/dnpc tp <id>");
        if (d == null) return;
        var w = Bukkit.getWorld(d.world);
        if (w == null) {
            msg(s, "<red>That world is not loaded.");
            return;
        }
        p.teleport(new Location(w, d.x, d.y, d.z, d.yaw, d.pitch));
        msg(s, "<green>Teleported to <white>" + d.id + "<green>.");
    }

    private void moveHere(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) {
            msg(s, "<red>Only players can do that.");
            return;
        }
        NpcData d = need(s, a, 1, "/dnpc movehere <id>");
        if (d == null) return;
        Location l = p.getLocation();
        d.world = l.getWorld().getName();
        d.x = l.getX();
        d.y = l.getY();
        d.z = l.getZ();
        d.yaw = l.getYaw();
        d.pitch = l.getPitch();
        mgr.update(d);
        msg(s, "<green>Moved <white>" + d.id + "<green> to your position.");
    }

    private void skin(CommandSender s, String[] a) {
        NpcData d = need(s, a, 1, "/dnpc skin <id> <playername>");
        if (d == null) return;
        if (a.length < 3) {
            msg(s, "<gray>Usage: <white>/dnpc skin <id> <playername>");
            return;
        }
        if (!a[2].matches("[!-~]{1,16}")) {
            msg(s, "<red>Invalid player name.");
            return;
        }
        d.skinName = a[2];
        d.skinValue = null;
        d.skinSignature = null;
        mgr.update(d);
        msg(s, "<green>Skin of <white>" + d.id + "<green> set to <white>" + a[2] + "<green>. It may take a few seconds to load.");
    }

    private void skinRaw(CommandSender s, String[] a) {
        NpcData d = need(s, a, 1, "/dnpc skinraw <id> <value> <signature>");
        if (d == null) return;
        if (a.length < 4) {
            msg(s, "<gray>Usage: <white>/dnpc skinraw <id> <value> <signature>");
            return;
        }
        d.skinValue = a[2];
        d.skinSignature = a[3];
        d.skinName = null;
        mgr.update(d);
        msg(s, "<green>Custom skin texture applied to <white>" + d.id + "<green>.");
    }

    private void skinReset(CommandSender s, String[] a) {
        NpcData d = need(s, a, 1, "/dnpc skinreset <id>");
        if (d == null) return;
        d.skinName = null;
        d.skinValue = null;
        d.skinSignature = null;
        mgr.update(d);
        msg(s, "<green>Skin reset for <white>" + d.id + "<green>.");
    }

    private void look(CommandSender s, String[] a) {
        NpcData d = need(s, a, 1, "/dnpc look <id> <on|off>");
        if (d == null) return;
        if (a.length < 3 || !(a[2].equalsIgnoreCase("on") || a[2].equalsIgnoreCase("off"))) {
            msg(s, "<gray>Usage: <white>/dnpc look <id> <on|off>");
            return;
        }
        d.look = a[2].equalsIgnoreCase("on");
        mgr.update(d);
        msg(s, "<green>Looking at players is now <white>" + (d.look ? "on" : "off") + "<green> for <white>" + d.id + "<green>.");
    }

    private void lookRange(CommandSender s, String[] a) {
        NpcData d = need(s, a, 1, "/dnpc lookrange <id> <blocks>");
        if (d == null) return;
        Double r = a.length >= 3 ? parseDouble(a[2]) : null;
        if (r == null || r < 1 || r > 64) {
            msg(s, "<gray>Usage: <white>/dnpc lookrange <id> <1-64>");
            return;
        }
        d.lookRange = r;
        mgr.save();
        msg(s, "<green>Look range of <white>" + d.id + "<green> set to <white>" + r + "<green> blocks.");
    }

    private void cooldown(CommandSender s, String[] a) {
        NpcData d = need(s, a, 1, "/dnpc cooldown <id> <seconds>");
        if (d == null) return;
        Integer n = a.length >= 3 ? parseInt(a[2]) : null;
        if (n == null || n < 0) {
            msg(s, "<gray>Usage: <white>/dnpc cooldown <id> <seconds>");
            return;
        }
        d.cooldown = n;
        mgr.save();
        msg(s, "<green>Click cooldown of <white>" + d.id + "<green> set to <white>" + n + "s<green>.");
    }

    private void holo(CommandSender s, String[] a) {
        String usage = "/dnpc holo <id> <add|set|remove|clear|height> ...";
        NpcData d = need(s, a, 1, usage);
        if (d == null) return;
        if (a.length < 3) {
            msg(s, "<gray>Usage: <white>" + usage);
            return;
        }
        switch (a[2].toLowerCase(Locale.ROOT)) {
            case "add" -> {
                if (a.length < 4) {
                    msg(s, "<gray>Usage: <white>/dnpc holo <id> add <text>");
                    return;
                }
                d.hologram.add(join(a, 3));
            }
            case "set" -> {
                Integer n = a.length >= 5 ? parseInt(a[3]) : null;
                if (n == null) {
                    msg(s, "<gray>Usage: <white>/dnpc holo <id> set <line> <text>");
                    return;
                }
                if (n < 1 || n > d.hologram.size()) {
                    msg(s, "<red>Line must be between 1 and " + d.hologram.size() + ".");
                    return;
                }
                d.hologram.set(n - 1, join(a, 4));
            }
            case "remove" -> {
                Integer n = a.length >= 4 ? parseInt(a[3]) : null;
                if (n == null || n < 1 || n > d.hologram.size()) {
                    msg(s, "<red>Usage: /dnpc holo <id> remove <line 1-" + d.hologram.size() + ">");
                    return;
                }
                d.hologram.remove(n - 1);
            }
            case "clear" -> d.hologram.clear();
            case "height" -> {
                Double h = a.length >= 4 ? parseDouble(a[3]) : null;
                if (h == null || h < -5 || h > 10) {
                    msg(s, "<gray>Usage: <white>/dnpc holo <id> height <blocks>");
                    return;
                }
                d.holoHeight = h;
            }
            default -> {
                msg(s, "<gray>Usage: <white>" + usage);
                return;
            }
        }
        mgr.update(d);
        msg(s, "<green>Hologram of <white>" + d.id + "<green> updated.");
    }

    private void cmd(CommandSender s, String[] a) {
        String usage = "/dnpc cmd <id> <add|remove|list|clear> ...";
        NpcData d = need(s, a, 1, usage);
        if (d == null) return;
        if (a.length < 3) {
            msg(s, "<gray>Usage: <white>" + usage);
            return;
        }
        switch (a[2].toLowerCase(Locale.ROOT)) {
            case "add" -> {
                if (a.length < 5) {
                    msg(s, "<gray>Usage: <white>/dnpc cmd <id> add <console|player|message> <text>");
                    return;
                }
                String type = a[3].toLowerCase(Locale.ROOT);
                if (!List.of("console", "player", "message").contains(type)) {
                    msg(s, "<red>Type must be console, player or message.");
                    return;
                }
                d.commands.add("[" + type + "] " + join(a, 4));
                mgr.save();
                msg(s, "<green>Added click action to <white>" + d.id + "<green>.");
            }
            case "remove" -> {
                Integer n = a.length >= 4 ? parseInt(a[3]) : null;
                if (n == null || n < 1 || n > d.commands.size()) {
                    msg(s, "<red>Usage: /dnpc cmd <id> remove <number 1-" + d.commands.size() + ">");
                    return;
                }
                d.commands.remove(n - 1);
                mgr.save();
                msg(s, "<green>Removed click action #" + n + ".");
            }
            case "list" -> {
                if (d.commands.isEmpty()) {
                    msg(s, "<gray>No click actions set for <white>" + d.id + "<gray>.");
                    return;
                }
                int i = 1;
                for (String line : d.commands) {
                    s.sendMessage(Text.parse("<dark_gray>" + (i++) + ". <white>" + line.replace("<", "\\<")));
                }
            }
            case "clear" -> {
                d.commands.clear();
                mgr.save();
                msg(s, "<green>All click actions removed from <white>" + d.id + "<green>.");
            }
            default -> msg(s, "<gray>Usage: <white>" + usage);
        }
    }

    private void templates(CommandSender s) {
        msg(s, "<gray>Templates: <white>" + String.join(", ", templateNames()));
    }

    private void reload(CommandSender s) {
        plugin.reloadConfig();
        mgr.load();
        msg(s, "<green>Reloaded config and NPCs.");
    }

    private List<String> templateNames() {
        ConfigurationSection t = plugin.getConfig().getConfigurationSection("templates");
        return t == null ? List.of() : new ArrayList<>(t.getKeys(false));
    }

    // ------------------------------------------------------------------ tab completion

    private static List<String> filter(List<String> options, String typed) {
        String t = typed.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : options) if (o.toLowerCase(Locale.ROOT).startsWith(t)) out.add(o);
        return out;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("divinenpcs.admin")) return List.of();
        if (a.length == 1) return filter(SUBS, a[0]);
        String sub = a[0].toLowerCase(Locale.ROOT);
        if (a.length == 2 && NEEDS_ID.contains(sub)) return filter(new ArrayList<>(mgr.ids()), a[1]);
        if (a.length == 3) {
            switch (sub) {
                case "create": return filter(templateNames(), a[2]);
                case "skin": {
                    List<String> names = new ArrayList<>();
                    for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
                    return filter(names, a[2]);
                }
                case "look": return filter(List.of("on", "off"), a[2]);
                case "holo": return filter(List.of("add", "set", "remove", "clear", "height"), a[2]);
                case "cmd": return filter(List.of("add", "remove", "list", "clear"), a[2]);
                default: break;
            }
        }
        if (a.length == 4 && sub.equals("cmd") && a[2].equalsIgnoreCase("add")) {
            return filter(List.of("console", "player", "message"), a[3]);
        }
        return List.of();
    }
}
