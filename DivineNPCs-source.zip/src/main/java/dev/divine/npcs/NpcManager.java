package dev.divine.npcs;

import com.destroystokyo.paper.profile.ProfileProperty;
import io.papermc.paper.datacomponent.item.ResolvableProfile;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Mannequin;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class NpcManager {
    private final DivineNPCs plugin;
    private final Map<String, NpcData> npcs = new LinkedHashMap<>();
    private final Map<String, Long> cooldowns = new HashMap<>();
    private final NamespacedKey idKey;
    private final File file;
    private BukkitTask lookTask;
    private BukkitTask ensureTask;

    public NpcManager(DivineNPCs plugin) {
        this.plugin = plugin;
        this.idKey = new NamespacedKey(plugin, "npc_id");
        this.file = new File(plugin.getDataFolder(), "npcs.yml");
    }

    public NamespacedKey idKey() { return idKey; }

    public List<NpcData> all() { return new ArrayList<>(npcs.values()); }

    public NpcData get(String id) {
        return id == null ? null : npcs.get(id.toLowerCase(Locale.ROOT));
    }

    public void add(NpcData d) {
        npcs.put(d.id, d);
        save();
        spawn(d);
    }

    public void remove(NpcData d) {
        despawn(d);
        npcs.remove(d.id);
        save();
    }

    public void update(NpcData d) {
        save();
        spawn(d);
    }

    // ------------------------------------------------------------------ storage

    public void load() {
        despawnAll();
        npcs.clear();
        cooldowns.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("npcs");
        if (root != null) {
            var cfg = plugin.getConfig();
            for (String id : root.getKeys(false)) {
                ConfigurationSection s = root.getConfigurationSection(id);
                if (s == null) continue;
                NpcData d = new NpcData(id.toLowerCase(Locale.ROOT));
                d.world = s.getString("world", "world");
                d.x = s.getDouble("x");
                d.y = s.getDouble("y");
                d.z = s.getDouble("z");
                d.yaw = (float) s.getDouble("yaw");
                d.pitch = (float) s.getDouble("pitch");
                String sn = s.getString("skin-name");
                d.skinName = (sn == null || sn.isBlank()) ? null : sn;
                String sv = s.getString("skin-value");
                d.skinValue = (sv == null || sv.isBlank()) ? null : sv;
                String ss = s.getString("skin-signature");
                d.skinSignature = (ss == null || ss.isBlank()) ? null : ss;
                d.look = s.getBoolean("look", true);
                d.lookRange = s.getDouble("look-range", cfg.getDouble("look.default-range", 8.0));
                d.holoHeight = s.getDouble("hologram-height", cfg.getDouble("hologram.default-height", 2.15));
                d.cooldown = s.getInt("cooldown", cfg.getInt("interact.default-cooldown-seconds", 1));
                d.hologram.addAll(s.getStringList("hologram"));
                d.commands.addAll(s.getStringList("commands"));
                npcs.put(d.id, d);
            }
        }
        spawnAll();
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (NpcData d : npcs.values()) {
            String p = "npcs." + d.id + ".";
            y.set(p + "world", d.world);
            y.set(p + "x", d.x);
            y.set(p + "y", d.y);
            y.set(p + "z", d.z);
            y.set(p + "yaw", (double) d.yaw);
            y.set(p + "pitch", (double) d.pitch);
            y.set(p + "skin-name", d.skinName);
            y.set(p + "skin-value", d.skinValue);
            y.set(p + "skin-signature", d.skinSignature);
            y.set(p + "look", d.look);
            y.set(p + "look-range", d.lookRange);
            y.set(p + "hologram-height", d.holoHeight);
            y.set(p + "cooldown", d.cooldown);
            y.set(p + "hologram", d.hologram);
            y.set(p + "commands", d.commands);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Could not save npcs.yml: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------ tasks

    public void startTasks() {
        long interval = Math.max(1, plugin.getConfig().getLong("look.update-interval-ticks", 2));
        lookTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tickLook, 20L, interval);
        ensureTask = Bukkit.getScheduler().runTaskTimer(plugin, this::ensureAll, 40L, 100L);
    }

    public void shutdown() {
        if (lookTask != null) lookTask.cancel();
        if (ensureTask != null) ensureTask.cancel();
        despawnAll();
    }

    private void tickLook() {
        for (NpcData d : npcs.values()) {
            if (!d.look) continue;
            Entity e = find(d.entityUuid);
            if (e == null) continue;

            Location el = e.getLocation();
            Player best = null;
            double bestDist = d.lookRange * d.lookRange;
            for (Player p : e.getWorld().getPlayers()) {
                if (p.getGameMode() == GameMode.SPECTATOR) continue;
                double dist = p.getLocation().distanceSquared(el);
                if (dist <= bestDist) {
                    best = p;
                    bestDist = dist;
                }
            }

            float ty;
            float tp;
            if (best == null) {
                ty = d.yaw;
                tp = d.pitch;
            } else {
                Location eye = best.getEyeLocation();
                double dx = eye.getX() - el.getX();
                double dy = eye.getY() - (el.getY() + 1.62);
                double dz = eye.getZ() - el.getZ();
                double h = Math.sqrt(dx * dx + dz * dz);
                ty = (float) Math.toDegrees(Math.atan2(-dx, dz));
                tp = (float) -Math.toDegrees(Math.atan2(dy, h));
            }
            float yawDiff = ((el.getYaw() - ty + 540f) % 360f) - 180f;
            if (Math.abs(yawDiff) > 1.5f || Math.abs(el.getPitch() - tp) > 1.5f) {
                e.setRotation(ty, tp);
            }
        }
    }

    private void ensureAll() {
        for (NpcData d : npcs.values()) {
            boolean npcOk = find(d.entityUuid) != null;
            boolean holoOk = d.hologram.isEmpty() || find(d.holoUuid) != null;
            if (!npcOk || !holoOk) spawn(d);
        }
    }

    // ------------------------------------------------------------------ spawning

    private Entity find(UUID uuid) {
        if (uuid == null) return null;
        Entity e = Bukkit.getEntity(uuid);
        return (e != null && e.isValid()) ? e : null;
    }

    public boolean isTracked(UUID uuid) {
        for (NpcData d : npcs.values()) {
            if (uuid.equals(d.entityUuid) || uuid.equals(d.holoUuid)) return true;
        }
        return false;
    }

    public void spawnAll() {
        for (NpcData d : npcs.values()) spawn(d);
    }

    public void spawnInChunk(String worldName, int cx, int cz) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (NpcData d : npcs.values()) {
                if (!d.world.equals(worldName)) continue;
                if (((int) Math.floor(d.x) >> 4) != cx || ((int) Math.floor(d.z) >> 4) != cz) continue;
                boolean npcOk = find(d.entityUuid) != null;
                boolean holoOk = d.hologram.isEmpty() || find(d.holoUuid) != null;
                if (!npcOk || !holoOk) spawn(d);
            }
        });
    }

    private ResolvableProfile profile(NpcData d) {
        if (d.skinValue != null) {
            return ResolvableProfile.resolvableProfile()
                    .name("DivineNPC")
                    .uuid(UUID.nameUUIDFromBytes(("divinenpcs:" + d.id).getBytes(StandardCharsets.UTF_8)))
                    .addProperty(new ProfileProperty("textures", d.skinValue, d.skinSignature))
                    .build();
        }
        if (d.skinName != null) {
            return ResolvableProfile.resolvableProfile().name(d.skinName).build();
        }
        return null;
    }

    private Component hologramText(NpcData d) {
        Component out = Component.empty();
        for (int i = 0; i < d.hologram.size(); i++) {
            if (i > 0) out = out.append(Component.newline());
            out = out.append(Text.parse(d.hologram.get(i).replace("{id}", d.id)));
        }
        return out;
    }

    public void spawn(NpcData d) {
        despawn(d);
        World w = Bukkit.getWorld(d.world);
        if (w == null) return;
        if (!w.isChunkLoaded((int) Math.floor(d.x) >> 4, (int) Math.floor(d.z) >> 4)) return;

        Location loc = new Location(w, d.x, d.y, d.z, d.yaw, d.pitch);
        ResolvableProfile prof = profile(d);

        Mannequin m = w.spawn(loc, Mannequin.class, e -> {
            e.setImmovable(true);
            e.setInvulnerable(true);
            e.setGravity(false);
            e.setSilent(true);
            e.setPersistent(false);
            e.setRemoveWhenFarAway(false);
            e.setCollidable(false);
            e.setCanPickupItems(false);
            e.setCustomNameVisible(false);
            e.setDescription((Component) null);
            if (prof != null) e.setProfile(prof);
            e.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, d.id);
        });
        d.entityUuid = m.getUniqueId();

        if (!d.hologram.isEmpty()) {
            boolean transparent = plugin.getConfig().getBoolean("hologram.transparent-background", true);
            boolean shadow = plugin.getConfig().getBoolean("hologram.shadow", true);
            Component text = hologramText(d);
            TextDisplay t = w.spawn(loc.clone().add(0, d.holoHeight, 0), TextDisplay.class, e -> {
                e.text(text);
                e.setBillboard(Display.Billboard.CENTER);
                e.setAlignment(TextDisplay.TextAlignment.CENTER);
                e.setShadowed(shadow);
                e.setSeeThrough(false);
                if (transparent) {
                    e.setDefaultBackground(false);
                    e.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
                }
                e.setPersistent(false);
                e.setInvulnerable(true);
                e.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, d.id);
            });
            d.holoUuid = t.getUniqueId();
        }
    }

    public void despawn(NpcData d) {
        removeEntity(d.entityUuid);
        removeEntity(d.holoUuid);
        d.entityUuid = null;
        d.holoUuid = null;
    }

    public void despawnAll() {
        for (NpcData d : npcs.values()) despawn(d);
    }

    private void removeEntity(UUID uuid) {
        if (uuid == null) return;
        Entity e = Bukkit.getEntity(uuid);
        if (e != null) e.remove();
    }

    // ------------------------------------------------------------------ interaction

    public void interact(String id, Player p) {
        NpcData d = get(id);
        if (d == null || !p.hasPermission("divinenpcs.use")) return;

        if (d.cooldown > 0 && !p.hasPermission("divinenpcs.bypass")) {
            String key = p.getUniqueId() + ":" + d.id;
            long now = System.currentTimeMillis();
            Long last = cooldowns.get(key);
            if (last != null && now - last < d.cooldown * 1000L) {
                p.sendActionBar(Text.parse("<red>Please wait a moment before clicking again."));
                return;
            }
            cooldowns.put(key, now);
        }
        run(d, p);
    }

    public void run(NpcData d, Player p) {
        for (String raw : new ArrayList<>(d.commands)) {
            String line = raw.replace("{player}", p.getName())
                    .replace("{uuid}", p.getUniqueId().toString())
                    .replace("{npc}", d.id)
                    .trim();
            String type = "player";
            if (line.startsWith("[")) {
                int end = line.indexOf(']');
                if (end > 0) {
                    type = line.substring(1, end).toLowerCase(Locale.ROOT);
                    line = line.substring(end + 1).trim();
                }
            }
            if (type.equals("message")) {
                p.sendMessage(Text.parse(line));
                continue;
            }
            if (line.startsWith("/")) line = line.substring(1);
            if (line.isEmpty()) continue;
            if (type.equals("console")) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), line);
            } else {
                p.performCommand(line);
            }
        }
    }

    public Collection<String> ids() {
        return new ArrayList<>(npcs.keySet());
    }
}
