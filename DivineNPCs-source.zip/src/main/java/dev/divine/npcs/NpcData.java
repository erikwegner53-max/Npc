package dev.divine.npcs;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class NpcData {
    public final String id;
    public String world = "world";
    public double x, y, z;
    public float yaw, pitch;

    public String skinName;
    public String skinValue;
    public String skinSignature;

    public boolean look = true;
    public double lookRange = 8.0;
    public double holoHeight = 2.15;
    public int cooldown = 1;

    public final List<String> hologram = new ArrayList<>();
    public final List<String> commands = new ArrayList<>();

    public UUID entityUuid;
    public UUID holoUuid;

    public NpcData(String id) {
        this.id = id;
    }
}
