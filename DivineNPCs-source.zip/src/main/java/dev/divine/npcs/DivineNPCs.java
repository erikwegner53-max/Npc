package dev.divine.npcs;

import net.kyori.adventure.text.Component;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class DivineNPCs extends JavaPlugin {
    private NpcManager manager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        manager = new NpcManager(this);
        manager.load();
        getServer().getPluginManager().registerEvents(new NpcListener(manager), this);

        PluginCommand cmd = getCommand("dnpc");
        if (cmd != null) {
            NpcCommand exec = new NpcCommand(this, manager);
            cmd.setExecutor(exec);
            cmd.setTabCompleter(exec);
        }
        manager.startTasks();
        getLogger().info("DivineNPCs enabled - " + manager.all().size() + " NPC(s) loaded.");
    }

    @Override
    public void onDisable() {
        if (manager != null) manager.shutdown();
    }

    public void send(CommandSender to, String mini) {
        Component prefix = Text.parse(getConfig().getString("prefix", ""));
        to.sendMessage(prefix.append(Text.parse(mini)));
    }
}
