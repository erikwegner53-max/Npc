package dev.divine.npcs;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class NpcListener implements Listener {
    private final NpcManager mgr;
    private final Map<UUID, Long> lastClick = new HashMap<>();

    public NpcListener(NpcManager mgr) {
        this.mgr = mgr;
    }

    private String npcId(Entity e) {
        return e.getPersistentDataContainer().get(mgr.idKey(), PersistentDataType.STRING);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEntityEvent e) {
        String id = npcId(e.getRightClicked());
        if (id == null) return;
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) return;

        Player p = e.getPlayer();
        long now = System.currentTimeMillis();
        Long last = lastClick.get(p.getUniqueId());
        if (last != null && now - last < 250) return; // dedupe interact / interact-at
        lastClick.put(p.getUniqueId(), now);

        mgr.interact(id, p);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent e) {
        if (npcId(e.getEntity()) != null) e.setCancelled(true);
    }

    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        for (Entity ent : e.getEntities()) {
            if (npcId(ent) != null && !mgr.isTracked(ent.getUniqueId())) {
                ent.remove(); // orphan left behind by a crash
            }
        }
        mgr.spawnInChunk(e.getWorld().getName(), e.getChunk().getX(), e.getChunk().getZ());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        lastClick.remove(e.getPlayer().getUniqueId());
    }
}
