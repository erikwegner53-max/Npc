rootProject.name = "DivineNPCs"
