# DivineNPCs
Paper/Purpur 26.3 plugin (Java 25). Build: `gradle build` -> build/libs/DivineNPCs-1.0.0.jar
